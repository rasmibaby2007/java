<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"
         import="java.util.*, com.typefast.model.LeaderboardEntry" %>
<%!
    // Escapes text so a username can never break the page.
    private static String esc(String s) {
        if (s == null) return "";
        StringBuilder sb = new StringBuilder();
        for (char c : s.toCharArray()) {
            switch (c) {
                case '&':  sb.append("&amp;");  break;
                case '<':  sb.append("&lt;");   break;
                case '>':  sb.append("&gt;");   break;
                case '"':  sb.append("&quot;"); break;
                case '\'': sb.append("&#39;");  break;
                default:   sb.append(c);
            }
        }
        return sb.toString();
    }

    private static String fmt(double v) {
        return String.format(Locale.US, "%.1f", v);
    }
%>
<%
    // Where your static HTML pages are served from (Live Server).
    final String HTML = "http://127.0.0.1:5500";

    // This page itself is served by Tomcat.
    String ctx = request.getContextPath();

    Object raw = request.getAttribute("leaderboard");

    // Opened directly (not through the servlet)? Go through the servlet so the data loads.
    // A forwarded request never redirects, so this can not loop.
    boolean forwarded = request.getAttribute("javax.servlet.forward.request_uri") != null
                     || request.getAttribute("jakarta.servlet.forward.request_uri") != null;

    if (raw == null && !forwarded) {
        response.sendRedirect(ctx + "/LeaderboardServlet");
        return;
    }

    @SuppressWarnings("unchecked")
    List<LeaderboardEntry> board = (raw == null)
            ? new ArrayList<LeaderboardEntry>()
            : (List<LeaderboardEntry>) raw;

    String[] medals = {"🥇", "🥈", "🥉"};
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leaderboard | TypeFast</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@500;700&display=swap" rel="stylesheet">

    <style>
        :root {
            --bg: #0b0714;
            --panel: #151024;
            --purple: #a855f7;
            --purple-light: #c084fc;
            --text: #f5f3ff;
            --muted: #958ba9;
            --border: #302343;
            --green: #4ade80;
            --amber: #fbbf24;
            --red: #fb7185;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            min-height: 100vh;
            color: var(--text);
            font-family: 'Inter', system-ui, sans-serif;
            background:
                radial-gradient(ellipse at top, #261344 0%, transparent 50%),
                var(--bg);
            background-attachment: fixed;
        }

        a { color: inherit; text-decoration: none; }

        /* ---------- Navbar ---------- */
        .navbar {
            min-height: 76px;
            padding: 0 7%;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 25px;
            border-bottom: 1px solid rgba(192, 132, 252, 0.13);
            background: rgba(11, 7, 20, 0.85);
        }

        .logo { font-size: 25px; font-weight: 800; letter-spacing: -1px; }
        .logo span { color: var(--purple-light); }

        .navbar nav { display: flex; align-items: center; gap: 28px; }
        .navbar nav a { color: var(--muted); font-size: 13px; transition: color .2s; }
        .navbar nav a:hover, .navbar nav a.active { color: var(--purple-light); }

        .signout {
            padding: 10px 15px;
            border: 1px solid var(--border);
            border-radius: 9px;
            font-size: 12px;
            transition: border-color .2s;
        }
        .signout:hover { border-color: var(--purple); }

        /* ---------- Layout ---------- */
        .container { width: min(100% - 36px, 860px); margin: 0 auto; }

        .heading { padding: 52px 0 30px; text-align: center; }

        .eyebrow {
            color: var(--purple-light);
            font-size: 11px;
            font-weight: 700;
            letter-spacing: 3px;
            margin-bottom: 14px;
        }

        .heading h1 { font-size: clamp(30px, 5vw, 42px); letter-spacing: -1.5px; margin-bottom: 12px; }
        .heading h1 span { color: var(--purple-light); }
        .heading p { color: var(--muted); font-size: 14px; line-height: 1.7; }

        /* ---------- Table ---------- */
        .card {
            padding: 14px 24px 24px;
            background: linear-gradient(145deg, #181126, #100b1b);
            border: 1px solid var(--border);
            border-radius: 20px;
            box-shadow: 0 18px 65px rgba(0, 0, 0, 0.25);
        }

        .table-wrap { overflow-x: auto; }

        table { width: 100%; border-collapse: collapse; }

        th {
            padding: 16px 12px;
            text-align: left;
            color: var(--muted);
            font-size: 10px;
            font-weight: 700;
            letter-spacing: 1.4px;
            border-bottom: 1px solid var(--border);
            white-space: nowrap;
        }

        td {
            padding: 15px 12px;
            font-size: 14px;
            border-bottom: 1px solid rgba(48, 35, 67, 0.6);
            white-space: nowrap;
        }

        tbody tr:last-child td { border-bottom: none; }
        tbody tr:hover td { background: rgba(168, 85, 247, 0.07); }

        .num { font-family: 'JetBrains Mono', monospace; }

        .rank { width: 70px; font-size: 18px; font-weight: 700; }
        .rank.plain { font-size: 14px; color: var(--muted); }

        .player { font-weight: 600; }

        .wpm { color: var(--purple-light); font-weight: 700; }
        .wpm small, .secs small { margin-left: 3px; color: var(--muted); font-family: 'Inter', sans-serif; font-size: 11px; font-weight: 500; }

        .secs { color: #e2d8f1; }

        .acc { font-weight: 700; }
        .acc.good { color: var(--green); }
        .acc.mid  { color: var(--amber); }
        .acc.low  { color: var(--red); }

        /* ---------- Empty state / error ---------- */
        .empty { padding: 56px 20px 40px; text-align: center; }
        .empty .big { font-size: 46px; margin-bottom: 12px; }
        .empty h2 { font-size: 20px; margin-bottom: 8px; }
        .empty p { color: var(--muted); font-size: 14px; }

        .alert {
            margin-bottom: 16px;
            padding: 12px 16px;
            color: var(--red);
            font-size: 13px;
            text-align: center;
            background: rgba(251, 113, 133, 0.08);
            border: 1px solid rgba(251, 113, 133, 0.3);
            border-radius: 12px;
        }

        /* ---------- Button ---------- */
        .actions { margin: 28px 0 6px; text-align: center; }

        .btn {
            display: inline-block;
            padding: 14px 26px;
            color: white;
            font-size: 13px;
            font-weight: 700;
            background: linear-gradient(110deg, #7c3aed, #a855f7);
            border-radius: 10px;
            box-shadow: 0 5px 20px rgba(124, 58, 237, 0.25);
            transition: transform .2s, box-shadow .2s;
        }

        .btn:hover { transform: translateY(-2px); box-shadow: 0 8px 26px rgba(168, 85, 247, 0.4); }

        .footer-note { padding: 30px 0 40px; text-align: center; color: #766b85; font-size: 11px; }
        .footer-note span { color: var(--purple-light); }

        /* ---------- Responsive ---------- */
        @media (max-width: 760px) {
            .navbar { padding: 18px 5%; flex-wrap: wrap; }
            .navbar nav { order: 3; width: 100%; justify-content: center; flex-wrap: wrap; gap: 15px 22px; }
        }

        @media (max-width: 520px) {
            .card { padding: 8px 12px 16px; }
            th, td { padding-left: 8px; padding-right: 8px; }
            td { font-size: 13px; }
        }
    </style>
</head>
<body>

<header class="navbar">
    <a href="<%= HTML %>/dashboard.html" class="logo">Type<span>Fast</span></a>

    <nav>
        <a href="<%= HTML %>/dashboard.html">Dashboard</a>
        <a href="<%= HTML %>/typing-test.html">Typing Test</a>
        <a href="<%= ctx %>/LeaderboardServlet" class="active">Leaderboard</a>
        <a href="<%= ctx %>/MyProfileServlet">My Profile</a>
    </nav>

    <a href="<%= HTML %>/signin.html" class="signout">Sign Out</a>
</header>

<main class="container">

    <section class="heading">
        <p class="eyebrow">TOP TYPISTS</p>
        <h1>Global <span>Leaderboard</span></h1>
        <p>Each player's best result, ranked by typing speed.</p>
    </section>

    <section class="card">

        <% if (request.getAttribute("error") != null) { %>
            <div class="alert"><%= esc((String) request.getAttribute("error")) %></div>
        <% } %>

        <% if (board.isEmpty()) { %>

            <div class="empty">
                <div class="big">🏆</div>
                <h2>No results yet</h2>
                <p>Take the typing test to be the first on the board.</p>
            </div>

        <% } else { %>

            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>RANK</th>
                            <th>PLAYER</th>
                            <th>SPEED</th>
                            <th>ACCURACY</th>
                            <th>TIME TAKEN</th>
                        </tr>
                    </thead>
                    <tbody>
                    <% for (LeaderboardEntry p : board) {
                           double acc = p.getAccuracy();
                           String accClass = (acc >= 95) ? "good" : (acc >= 80 ? "mid" : "low");
                           int rank = p.getRank();
                    %>
                        <tr>
                            <td class="rank num<%= rank > 3 ? " plain" : "" %>">
                                <%= rank <= 3 ? medals[rank - 1] : ("#" + rank) %>
                            </td>
                            <td class="player"><%= esc(p.getUsername()) %></td>
                            <td class="num wpm"><%= fmt(p.getWpm()) %><small>WPM</small></td>
                            <td class="num acc <%= accClass %>"><%= fmt(acc) %>%</td>
                            <td class="num secs"><%= p.getDurationSeconds() %><small>sec</small></td>
                        </tr>
                    <% } %>
                    </tbody>
                </table>
            </div>

        <% } %>

    </section>

    <div class="actions">
        <a href="<%= HTML %>/typing-test.html" class="btn">Take the Typing Test →</a>
    </div>

    <p class="footer-note"><span>TypeFast</span> — Every keystroke makes you better.</p>

</main>

</body>
</html>
