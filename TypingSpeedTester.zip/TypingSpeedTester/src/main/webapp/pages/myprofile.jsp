<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"
         import="java.util.*, java.text.SimpleDateFormat, com.typefast.model.UserProfile, com.typefast.model.TypingResult" %>
<%!
    // Escapes text so a name or email can never break the page.
    private static String esc(String s) {
        if (s == null) return "";
        StringBuilder sb = new StringBuilder();
        for (char c : s.toCharArray()) {
            switch (c) {
                case '&':  sb.append("&amp;");  break;
                case '<':  sb.append("&lt;");   break;
                case '>':  sb.append("&gt;");   break;
                case '"':  sb.append("&quot;"); break;
                case '\'': sb.append("&#39;");  break;
                default:   sb.append(c);
            }
        }
        return sb.toString();
    }

    private static String fmt(double v) {
        return String.format(Locale.US, "%.1f", v);
    }
%>
<%
    // Where your static HTML pages are served from (Live Server).
    final String HTML = "http://127.0.0.1:5500";

    // This page itself is served by Tomcat.
    String ctx = request.getContextPath();

    UserProfile profile = (UserProfile) request.getAttribute("profile");
    String error = (String) request.getAttribute("error");

    // Opened directly (not through the servlet)? Go through the servlet so the data loads.
    // A forwarded request never redirects, so this can not loop.
    boolean forwarded = request.getAttribute("javax.servlet.forward.request_uri") != null
                     || request.getAttribute("jakarta.servlet.forward.request_uri") != null;

    if (profile == null && error == null && !forwarded) {
        response.sendRedirect(ctx + "/MyProfileServlet");
        return;
    }

    @SuppressWarnings("unchecked")
    List<TypingResult> results = (request.getAttribute("results") == null)
            ? new ArrayList<TypingResult>()
            : (List<TypingResult>) request.getAttribute("results");

    SimpleDateFormat dateFmt = new SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.ENGLISH);
    SimpleDateFormat joinFmt = new SimpleDateFormat("MMMM yyyy", Locale.ENGLISH);

    String name = (profile == null || profile.getUsername() == null) ? "" : profile.getUsername().trim();
    String initial = name.isEmpty() ? "?" : name.substring(0, 1).toUpperCase();
    String phone = (profile == null || profile.getPhoneNumber() == null || profile.getPhoneNumber().trim().isEmpty())
            ? "Not added" : profile.getPhoneNumber();
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile | TypeFast</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@500;700&display=swap" rel="stylesheet">

    <style>
        :root {
            --bg: #0b0714;
            --panel-light: #20162f;
            --purple: #a855f7;
            --purple-light: #c084fc;
            --text: #f5f3ff;
            --muted: #958ba9;
            --border: #302343;
            --green: #4ade80;
            --amber: #fbbf24;
            --red: #fb7185;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            min-height: 100vh;
            color: var(--text);
            font-family: 'Inter', system-ui, sans-serif;
            background:
                radial-gradient(ellipse at top, #261344 0%, transparent 50%),
                var(--bg);
            background-attachment: fixed;
        }

        a { color: inherit; text-decoration: none; }

        /* ---------- Navbar ---------- */
        .navbar {
            min-height: 76px;
            padding: 0 7%;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 25px;
            border-bottom: 1px solid rgba(192, 132, 252, 0.13);
            background: rgba(11, 7, 20, 0.85);
        }

        .logo { font-size: 25px; font-weight: 800; letter-spacing: -1px; }
        .logo span { color: var(--purple-light); }

        .navbar nav { display: flex; align-items: center; gap: 28px; }
        .navbar nav a { color: var(--muted); font-size: 13px; transition: color .2s; }
        .navbar nav a:hover, .navbar nav a.active { color: var(--purple-light); }

        .signout {
            padding: 10px 15px;
            border: 1px solid var(--border);
            border-radius: 9px;
            font-size: 12px;
            transition: border-color .2s;
        }
        .signout:hover { border-color: var(--purple); }

        /* ---------- Layout ---------- */
        .container { width: min(100% - 36px, 860px); margin: 0 auto; padding-top: 44px; }

        .card {
            background: linear-gradient(145deg, #181126, #100b1b);
            border: 1px solid var(--border);
            border-radius: 20px;
            box-shadow: 0 18px 65px rgba(0, 0, 0, 0.25);
        }

        /* ---------- Profile header ---------- */
        .profile-head {
            display: flex;
            align-items: center;
            gap: 24px;
            padding: 30px;
        }

        .avatar {
            display: grid;
            place-items: center;
            flex-shrink: 0;
            width: 92px;
            height: 92px;
            border-radius: 50%;
            font-size: 38px;
            font-weight: 800;
            color: white;
            background: linear-gradient(135deg, #a855f7, #7c3aed);
            box-shadow: 0 0 0 5px rgba(168, 85, 247, 0.12), 0 10px 30px rgba(124, 58, 237, 0.35);
        }

        .who { min-width: 0; }

        .eyebrow {
            color: var(--purple-light);
            font-size: 11px;
            font-weight: 700;
            letter-spacing: 3px;
            margin-bottom: 8px;
        }

        .who h1 {
            font-size: clamp(24px, 4.5vw, 32px);
            letter-spacing: -1px;
            margin-bottom: 14px;
            overflow-wrap: anywhere;
        }

        .details { display: flex; flex-wrap: wrap; gap: 8px 22px; color: var(--muted); font-size: 13px; }
        .details b { color: #e2d8f1; font-weight: 600; }

        /* ---------- Stats ---------- */
        .stats {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 12px;
            margin: 16px 0;
        }

        .stat {
            padding: 20px 16px;
            background: var(--panel-light);
            border: 1px solid var(--border);
            border-radius: 14px;
        }

        .stat span {
            display: block;
            margin-bottom: 10px;
            color: var(--muted);
            font-size: 9px;
            font-weight: 700;
            letter-spacing: 1.4px;
        }

        .stat strong {
            font-family: 'JetBrains Mono', monospace;
            font-size: 24px;
            color: var(--purple-light);
        }

        .stat strong small { margin-left: 3px; color: var(--muted); font-family: 'Inter', sans-serif; font-size: 11px; font-weight: 600; }

        /* ---------- Recent tests ---------- */
        .recent { padding: 8px 24px 22px; }

        .recent h2 { padding: 18px 0 6px; font-size: 18px; letter-spacing: -.4px; }

        .table-wrap { overflow-x: auto; }

        table { width: 100%; border-collapse: collapse; }

        th {
            padding: 14px 12px;
            text-align: left;
            color: var(--muted);
            font-size: 10px;
            font-weight: 700;
            letter-spacing: 1.4px;
            border-bottom: 1px solid var(--border);
            white-space: nowrap;
        }

        td {
            padding: 14px 12px;
            font-size: 14px;
            border-bottom: 1px solid rgba(48, 35, 67, 0.6);
            white-space: nowrap;
        }

        tbody tr:last-child td { border-bottom: none; }
        tbody tr:hover td { background: rgba(168, 85, 247, 0.07); }

        .num { font-family: 'JetBrains Mono', monospace; }
        .muted-cell { color: var(--muted); }

        td small { margin-left: 3px; color: var(--muted); font-family: 'Inter', sans-serif; font-size: 11px; }

        .wpm { color: var(--purple-light); font-weight: 700; }
        .acc { font-weight: 700; }
        .acc.good { color: var(--green); }
        .acc.mid  { color: var(--amber); }
        .acc.low  { color: var(--red); }

        .empty { padding: 44px 20px 30px; text-align: center; }
        .empty .big { font-size: 42px; margin-bottom: 10px; }
        .empty p { color: var(--muted); font-size: 14px; }

        .alert {
            padding: 14px 16px;
            margin-bottom: 16px;
            color: var(--red);
            font-size: 13px;
            text-align: center;
            background: rgba(251, 113, 133, 0.08);
            border: 1px solid rgba(251, 113, 133, 0.3);
            border-radius: 12px;
        }

        /* ---------- Buttons ---------- */
        .actions { display: flex; justify-content: center; flex-wrap: wrap; gap: 12px; margin: 28px 0 6px; }

        .btn {
            display: inline-block;
            padding: 14px 26px;
            font-size: 13px;
            font-weight: 700;
            border-radius: 10px;
            transition: transform .2s, box-shadow .2s, border-color .2s;
        }

        .btn.primary {
            color: white;
            background: linear-gradient(110deg, #7c3aed, #a855f7);
            box-shadow: 0 5px 20px rgba(124, 58, 237, 0.25);
        }

        .btn.primary:hover { transform: translateY(-2px); box-shadow: 0 8px 26px rgba(168, 85, 247, 0.4); }

        .btn.ghost { color: var(--purple-light); border: 1px solid var(--border); }
        .btn.ghost:hover { border-color: var(--purple); }

        .footer-note { padding: 30px 0 40px; text-align: center; color: #766b85; font-size: 11px; }
        .footer-note span { color: var(--purple-light); }

        /* ---------- Responsive ---------- */
        @media (max-width: 760px) {
            .navbar { padding: 18px 5%; flex-wrap: wrap; }
            .navbar nav { order: 3; width: 100%; justify-content: center; flex-wrap: wrap; gap: 15px 22px; }
            .stats { grid-template-columns: repeat(2, minmax(0, 1fr)); }
        }

        @media (max-width: 520px) {
            .profile-head { flex-direction: column; text-align: center; padding: 24px 18px; }
            .details { justify-content: center; }
            .recent { padding: 4px 12px 16px; }
            th, td { padding-left: 8px; padding-right: 8px; }
            td { font-size: 13px; }
        }
    </style>
</head>
<body>

<header class="navbar">
    <a href="<%= HTML %>/dashboard.html" class="logo">Type<span>Fast</span></a>

    <nav>
        <a href="<%= HTML %>/dashboard.html">Dashboard</a>
        <a href="<%= HTML %>/typing-test.html">Typing Test</a>
        <a href="<%= ctx %>/LeaderboardServlet">Leaderboard</a>
        <a href="<%= ctx %>/MyProfileServlet" class="active">My Profile</a>
    </nav>

    <a href="<%= HTML %>/signin.html" class="signout">Sign Out</a>
</header>

<main class="container">

    <% if (error != null) { %>
        <div class="alert"><%= esc(error) %></div>
    <% } %>

    <% if (profile != null) { %>

        <!-- ===== Who you are ===== -->
        <section class="card profile-head">
            <div class="avatar"><%= esc(initial) %></div>

            <div class="who">
                <p class="eyebrow">MY PROFILE</p>
                <h1><%= esc(name) %></h1>

                <div class="details">
                    <span>Email: <b><%= esc(profile.getEmail()) %></b></span>
                    <span>Phone: <b><%= esc(phone) %></b></span>
                    <span>Member since: <b><%= profile.getCreatedAt() == null ? "-" : joinFmt.format(profile.getCreatedAt()) %></b></span>
                </div>
            </div>
        </section>

        <!-- ===== Stats ===== -->
        <section class="stats">
            <div class="stat">
                <span>TESTS TAKEN</span>
                <strong><%= profile.getTotalTests() %></strong>
            </div>
            <div class="stat">
                <span>BEST SPEED</span>
                <strong><%= fmt(profile.getBestWpm()) %><small>WPM</small></strong>
            </div>
            <div class="stat">
                <span>AVERAGE SPEED</span>
                <strong><%= fmt(profile.getAvgWpm()) %><small>WPM</small></strong>
            </div>
            <div class="stat">
                <span>AVG ACCURACY</span>
                <strong><%= fmt(profile.getAvgAccuracy()) %><small>%</small></strong>
            </div>
        </section>

        <!-- ===== Recent tests ===== -->
        <section class="card recent">
            <h2>Recent Tests</h2>

            <% if (results.isEmpty()) { %>

                <div class="empty">
                    <div class="big">⌨️</div>
                    <p>You have not taken a typing test yet.</p>
                </div>

            <% } else { %>

                <div class="table-wrap">
                    <table>
                        <thead>
                            <tr>
                                <th>DATE</th>
                                <th>SPEED</th>
                                <th>ACCURACY</th>
                                <th>TIME TAKEN</th>
                            </tr>
                        </thead>
                        <tbody>
                        <% for (TypingResult r : results) {
                               double acc = r.getAccuracy();
                               String accClass = (acc >= 95) ? "good" : (acc >= 80 ? "mid" : "low");
                        %>
                            <tr>
                                <td class="muted-cell"><%= r.getCompletedAt() == null ? "-" : dateFmt.format(r.getCompletedAt()) %></td>
                                <td class="num wpm"><%= fmt(r.getWpm()) %><small>WPM</small></td>
                                <td class="num acc <%= accClass %>"><%= fmt(acc) %>%</td>
                                <td class="num"><%= r.getDurationSeconds() %><small>sec</small></td>
                            </tr>
                        <% } %>
                        </tbody>
                    </table>
                </div>

            <% } %>
        </section>

    <% } %>

    <div class="actions">
        <a href="<%= HTML %>/typing-test.html" class="btn primary">Take the Typing Test →</a>
        <a href="<%= ctx %>/LeaderboardServlet" class="btn ghost">View Leaderboard</a>
    </div>

    <p class="footer-note"><span>TypeFast</span> — Every keystroke makes you better.</p>

</main>

</body>
</html>
