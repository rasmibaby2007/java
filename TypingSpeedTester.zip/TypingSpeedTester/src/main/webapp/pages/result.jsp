<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" import="java.util.Locale" %>
<%
    // Opened directly without a test? Send the user back to the typing page.
    Object wpmObj = request.getAttribute("wpm");
    if (wpmObj == null) {
        response.sendRedirect("typing-test.html");
        return;
    }

    double wpm = ((Number) wpmObj).doubleValue();
    double accuracy = ((Number) request.getAttribute("accuracy")).doubleValue();
    int correctWords = ((Number) request.getAttribute("correctWords")).intValue();
    String seconds = String.valueOf(request.getAttribute("seconds"));
    boolean saved = !Boolean.FALSE.equals(request.getAttribute("saved"));

    String ctx = request.getContextPath();

    // Headline based on speed
    String title;
    String subtitle;
    if (wpm >= 60) {
        title = "Lightning fast!";
        subtitle = "You are typing like a pro. Keep that accuracy up.";
    } else if (wpm >= 40) {
        title = "Great speed!";
        subtitle = "You are above the average typing speed. Nice work.";
    } else if (wpm >= 20) {
        title = "Good progress!";
        subtitle = "Steady practice will push this number up quickly.";
    } else {
        title = "Keep practicing!";
        subtitle = "Every attempt makes you faster. Try another sentence.";
    }

    // Accuracy ring (SVG circle, radius 54)
    double circumference = 2 * Math.PI * 54;
    double clampedAccuracy = Math.max(0, Math.min(100, accuracy));
    double ringOffset = circumference * (1 - clampedAccuracy / 100.0);

    // Speed bar: 80 WPM fills the bar
    double speedPercent = Math.max(0, Math.min(100, wpm / 80.0 * 100.0));

    String wpmText = String.format(Locale.US, "%.1f", wpm);
    String accuracyText = String.format(Locale.US, "%.1f", accuracy);
    String circText = String.format(Locale.US, "%.2f", circumference);
    String offsetText = String.format(Locale.US, "%.2f", ringOffset);
    String speedText = String.format(Locale.US, "%.1f", speedPercent);
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Results | TypeFast</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@500;700&display=swap" rel="stylesheet">

    <style>
        :root {
            --bg: #0b0714;
            --panel-light: #20162f;
            --purple: #a855f7;
            --purple-deep: #7c3aed;
            --purple-light: #c084fc;
            --text: #f5f3ff;
            --muted: #958ba9;
            --border: #302343;
            --green: #4ade80;
            --red: #fb7185;
            --amber: #fbbf24;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            min-height: 100vh;
            color: var(--text);
            font-family: 'Inter', system-ui, sans-serif;
            background:
                radial-gradient(ellipse 80% 50% at 50% -10%, #3b1a6b 0%, transparent 60%),
                radial-gradient(ellipse 50% 40% at 90% 90%, rgba(124, 58, 237, 0.15) 0%, transparent 60%),
                var(--bg);
            background-attachment: fixed;
        }

        a { color: inherit; text-decoration: none; }

        /* ---------- Navbar ---------- */
        .navbar {
            min-height: 76px;
            padding: 0 7%;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 25px;
            border-bottom: 1px solid rgba(192, 132, 252, 0.13);
            background: rgba(11, 7, 20, 0.85);
            backdrop-filter: blur(10px);
        }

        .logo { font-size: 25px; font-weight: 800; letter-spacing: -1px; }
        .logo span { color: var(--purple-light); }

        .navbar nav { display: flex; align-items: center; gap: 28px; }
        .navbar nav a { color: var(--muted); font-size: 13px; transition: color .2s; }
        .navbar nav a:hover, .navbar nav a.active { color: var(--purple-light); }

        .signout {
            padding: 10px 15px;
            border: 1px solid var(--border);
            border-radius: 9px;
            font-size: 12px;
            transition: border-color .2s;
        }
        .signout:hover { border-color: var(--purple); }

        /* ---------- Layout ---------- */
        .container { width: min(100% - 36px, 860px); margin: 0 auto; padding: 48px 0 20px; }

        .card {
            position: relative;
            overflow: hidden;
            padding: 44px 36px 38px;
            text-align: center;
            background: linear-gradient(150deg, rgba(32, 22, 47, 0.95), rgba(16, 11, 27, 0.95));
            border: 1px solid var(--border);
            border-radius: 26px;
            box-shadow: 0 25px 80px rgba(0, 0, 0, 0.4), 0 0 0 1px rgba(168, 85, 247, 0.06);
            animation: rise .6s ease both;
        }

        /* glowing top edge */
        .card::before {
            content: "";
            position: absolute;
            top: 0; left: 15%; right: 15%;
            height: 2px;
            background: linear-gradient(90deg, transparent, var(--purple-light), transparent);
        }

        .eyebrow {
            color: var(--purple-light);
            font-size: 11px;
            font-weight: 700;
            letter-spacing: 3px;
            margin-bottom: 26px;
        }

        /* ---------- Accuracy ring ---------- */
        .ring {
            position: relative;
            width: 176px;
            height: 176px;
            margin: 0 auto 26px;
        }

        .ring svg { width: 100%; height: 100%; transform: rotate(-90deg); }

        .ring .track { fill: none; stroke: rgba(168, 85, 247, 0.12); stroke-width: 9; }

        .ring .progress {
            fill: none;
            stroke: url(#ringGradient);
            stroke-width: 9;
            stroke-linecap: round;
            stroke-dasharray: <%= circText %>;
            stroke-dashoffset: <%= circText %>;
            animation: fill 1.4s .3s cubic-bezier(.22, 1, .36, 1) forwards;
            filter: drop-shadow(0 0 8px rgba(168, 85, 247, .55));
        }

        .ring-center {
            position: absolute;
            inset: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }

        .ring-value {
            font-family: 'JetBrains Mono', monospace;
            font-size: 34px;
            font-weight: 700;
            line-height: 1;
        }

        .ring-value small { font-size: 18px; color: var(--purple-light); }

        .ring-label {
            margin-top: 8px;
            color: var(--muted);
            font-size: 10px;
            font-weight: 700;
            letter-spacing: 1.6px;
        }

        h1 {
            font-size: clamp(28px, 5vw, 38px);
            letter-spacing: -1.2px;
            margin-bottom: 10px;
        }

        h1 span {
            background: linear-gradient(110deg, #c084fc, #a855f7, #7c3aed);
            -webkit-background-clip: text;
            background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .subtitle { color: var(--muted); font-size: 14px; line-height: 1.7; }

        /* ---------- Stat cards ---------- */
        .stats {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 14px;
            margin: 34px 0 24px;
        }

        .stat {
            padding: 22px 14px 20px;
            text-align: left;
            background: rgba(32, 22, 47, 0.7);
            border: 1px solid var(--border);
            border-radius: 16px;
            transition: transform .25s, border-color .25s;
            animation: rise .6s ease both;
        }

        .stat:nth-child(1) { animation-delay: .15s; }
        .stat:nth-child(2) { animation-delay: .25s; }
        .stat:nth-child(3) { animation-delay: .35s; }

        .stat:hover { transform: translateY(-4px); border-color: rgba(168, 85, 247, 0.5); }

        .stat-top {
            display: flex;
            align-items: center;
            gap: 9px;
            margin-bottom: 14px;
            color: var(--muted);
            font-size: 10px;
            font-weight: 700;
            letter-spacing: 1.4px;
        }

        .stat-icon {
            display: grid;
            place-items: center;
            width: 28px;
            height: 28px;
            border-radius: 8px;
            font-size: 14px;
            background: rgba(168, 85, 247, 0.14);
        }

        .stat-value {
            font-family: 'JetBrains Mono', monospace;
            font-size: 30px;
            font-weight: 700;
            color: var(--purple-light);
            letter-spacing: -1px;
        }

        .stat-value small {
            font-family: 'Inter', sans-serif;
            font-size: 12px;
            font-weight: 600;
            color: var(--muted);
            letter-spacing: 0;
            margin-left: 3px;
        }

        .bar {
            height: 6px;
            margin-top: 16px;
            overflow: hidden;
            border-radius: 6px;
            background: rgba(168, 85, 247, 0.12);
        }

        .bar i {
            display: block;
            height: 100%;
            width: 0;
            border-radius: 6px;
            background: linear-gradient(90deg, var(--purple-deep), var(--purple-light));
            animation: grow 1.2s .5s cubic-bezier(.22, 1, .36, 1) forwards;
        }

        /* ---------- Saved banner ---------- */
        .banner {
            display: inline-flex;
            align-items: center;
            gap: 9px;
            padding: 10px 16px;
            margin-bottom: 30px;
            border-radius: 30px;
            font-size: 12px;
            font-weight: 600;
        }

        .banner.ok {
            color: var(--green);
            background: rgba(74, 222, 128, 0.08);
            border: 1px solid rgba(74, 222, 128, 0.25);
        }

        .banner.fail {
            color: var(--red);
            background: rgba(251, 113, 133, 0.08);
            border: 1px solid rgba(251, 113, 133, 0.3);
        }

        /* ---------- Buttons ---------- */
        .actions { display: flex; justify-content: center; flex-wrap: wrap; gap: 12px; }

        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            min-height: 48px;
            padding: 13px 26px;
            border-radius: 11px;
            font-size: 13px;
            font-weight: 700;
            transition: transform .2s, box-shadow .2s, border-color .2s, background .2s;
        }

        .btn.primary {
            color: white;
            background: linear-gradient(110deg, #7c3aed, #a855f7);
            box-shadow: 0 6px 22px rgba(124, 58, 237, 0.3);
        }

        .btn.primary:hover { transform: translateY(-2px); box-shadow: 0 9px 30px rgba(168, 85, 247, 0.45); }

        .btn.ghost {
            color: var(--purple-light);
            border: 1px solid var(--border);
            background: rgba(168, 85, 247, 0.04);
        }

        .btn.ghost:hover { border-color: var(--purple); background: rgba(168, 85, 247, 0.1); }

        .footer-note { padding: 34px 0 40px; text-align: center; color: #766b85; font-size: 11px; }
        .footer-note span { color: var(--purple-light); }

        /* ---------- Animations ---------- */
        @keyframes rise { from { opacity: 0; transform: translateY(18px); } to { opacity: 1; transform: none; } }
        @keyframes fill { to { stroke-dashoffset: <%= offsetText %>; } }
        @keyframes grow { to { width: var(--w); } }

        @media (prefers-reduced-motion: reduce) {
            *, *::before, *::after { animation-duration: .01ms !important; animation-delay: 0s !important; }
        }

        /* ---------- Responsive ---------- */
        @media (max-width: 760px) {
            .navbar { padding: 18px 5%; flex-wrap: wrap; }
            .navbar nav { order: 3; width: 100%; justify-content: center; flex-wrap: wrap; gap: 15px 22px; }
        }

        @media (max-width: 620px) {
            .card { padding: 34px 20px 30px; }
            .stats { grid-template-columns: 1fr; }
            .btn { width: 100%; }
        }
    </style>
</head>
<body>

<header class="navbar">
    <a href="http://127.0.0.1:5500/dashboard.html" class="logo">Type<span>Fast</span></a>

    <nav>
        <a href="http://127.0.0.1:5500/dashboard.html">Dashboard</a>
        <a href="http://127.0.0.1:5500/typing-test.html" class="active">Typing Test</a>
        <a href="/TypingSpeedTester/LeaderboardServlet">Leaderboard</a>
        <a href="/TypingSpeedTester/MyProfileServlet">My Profile</a>
    </nav>

    <a href="http://127.0.0.1:5500/signin.html" class="signout">Sign Out</a>
</header>

<main class="container">

    <section class="card">

        <p class="eyebrow">TEST COMPLETE</p>

        <div class="ring">
            <svg viewBox="0 0 120 120" aria-hidden="true">
                <defs>
                    <linearGradient id="ringGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stop-color="#c084fc"/>
                        <stop offset="100%" stop-color="#7c3aed"/>
                    </linearGradient>
                </defs>
                <circle class="track" cx="60" cy="60" r="54"/>
                <circle class="progress" cx="60" cy="60" r="54"/>
            </svg>

            <div class="ring-center">
                <div class="ring-value"><span data-count="<%= accuracyText %>"><%= accuracyText %></span><small>%</small></div>
                <div class="ring-label">ACCURACY</div>
            </div>
        </div>

        <h1><span><%= title %></span></h1>
        <p class="subtitle"><%= subtitle %></p>

        <div class="stats">

            <div class="stat">
                <div class="stat-top"><span class="stat-icon">⚡</span>TYPING SPEED</div>
                <div class="stat-value"><span data-count="<%= wpmText %>"><%= wpmText %></span><small>WPM</small></div>
                <div class="bar"><i style="--w: <%= speedText %>%"></i></div>
            </div>

            <div class="stat">
                <div class="stat-top"><span class="stat-icon">✓</span>CORRECT WORDS</div>
                <div class="stat-value"><span data-count="<%= correctWords %>"><%= correctWords %></span><small>words</small></div>
                <div class="bar"><i style="--w: <%= Math.min(100, correctWords * 100 / 20) %>%"></i></div>
            </div>

            <div class="stat">
                <div class="stat-top"><span class="stat-icon">⏱</span>TIME TAKEN</div>
                <div class="stat-value"><span><%= seconds %></span><small>sec</small></div>
                <div class="bar"><i style="--w: 100%"></i></div>
            </div>

        </div>

        <% if (saved) { %>
            <div class="banner ok">● Result saved to your profile</div>
        <% } else { %>
            <div class="banner fail">● Your result could not be saved to your profile</div>
        <% } %>

        <div class="actions">
            <a href="http://127.0.0.1:5500/typing-test.html" class="btn primary">Try Another Sentence ↻</a>
            <a href="/TypingSpeedTester/LeaderboardServlet" class="btn ghost" method="post">View Leaderboard</a>
        </div>

    </section>

    <p class="footer-note"><span>TypeFast</span> — Every keystroke makes you better.</p>

</main>

<script>
    // Count-up animation for the numbers (the final values are already in the HTML).
    document.querySelectorAll("[data-count]").forEach(function (el) {
        var target = parseFloat(el.getAttribute("data-count"));
        if (isNaN(target) || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;

        var decimals = (el.getAttribute("data-count").split(".")[1] || "").length;
        var duration = 1100;
        var start = null;

        function step(ts) {
            if (start === null) start = ts;
            var progress = Math.min((ts - start) / duration, 1);
            var eased = 1 - Math.pow(1 - progress, 3);
            el.textContent = (target * eased).toFixed(decimals);
            if (progress < 1) requestAnimationFrame(step);
        }

        el.textContent = (0).toFixed(decimals);
        requestAnimationFrame(step);
    });
</script>

</body>
</html>
