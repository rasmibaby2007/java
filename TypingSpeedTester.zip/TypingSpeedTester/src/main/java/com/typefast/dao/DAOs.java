package com.typefast.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.typefast.model.LeaderboardEntry;
import com.typefast.model.TypingResult;
import com.typefast.model.UserProfile;

public class DAOs {
	private static final String url = "jdbc:mysql://localhost:3306/typing_speed_tester";
	private static final String username = "root";
	private static final String dbPassword = "rejeeboxer585";
	public static void main(String[] args) {
		
	}
	public static boolean userSignupCheck(String user_name,String phone,String email) throws SQLException, ClassNotFoundException {
		String query = "select * from users where email = ? or phone_number = ? or username = ?;";
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection(url, username, dbPassword);
		PreparedStatement pst = con.prepareStatement(query);
		pst.setString(1, email);
		pst.setString(2, phone);
		pst.setString(3, user_name);
		ResultSet rs = pst.executeQuery();
		//System.out.println(rs.next());
		return rs.next();
	}
	public static void userSignup(String user_name,String phone,String email,String password) throws ClassNotFoundException, SQLException {
		String query = "insert into users(username,email,phone_number,password_hash) values (?,?,?,?);";
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection(url, username, dbPassword);
		PreparedStatement pst = con.prepareStatement(query);
		pst.setString(1, user_name);
		pst.setString(2, email);
		pst.setString(3, phone);
		pst.setString(4, password);
		pst.execute();
	}
	public static int signin(String email, String password) throws ClassNotFoundException, SQLException {
		String query = "select * from users where email = ? and password_hash = ?;";
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection(url, username, dbPassword);
		PreparedStatement pst = con.prepareStatement(query);
		pst.setString(1, email);
		pst.setString(2, password);
		ResultSet rs = pst.executeQuery();
		int res = 0;
		if(rs.next())
			res = rs.getInt("user_id");
		return res;
	}
	public static void addTypingResults(int user_id,double wpm,double accuracy,int sec) throws ClassNotFoundException, SQLException {
		String query = "insert into typing_results(user_id,wpm,accuracy,duration_seconds) values (?,?,?,?);";
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection(url, username, dbPassword);
		PreparedStatement pst = con.prepareStatement(query);
		pst.setInt(1, user_id);
		pst.setDouble(2, wpm);
		pst.setDouble(3, accuracy);
		pst.setInt(4, sec);
		pst.execute();
	}
	public static List<LeaderboardEntry> leaderboardDAO(int limit) throws ClassNotFoundException, SQLException{
		limit = 50;
		String query = """
		        SELECT u.user_id, u.username, r.wpm, r.accuracy, r.duration_seconds, r.completed_at
		        FROM typing_results r
		        JOIN users u ON u.user_id = r.user_id
		        WHERE r.result_id = (
		            SELECT r2.result_id FROM typing_results r2
		            WHERE r2.user_id = r.user_id
		            ORDER BY r2.wpm DESC, r2.accuracy DESC, r2.completed_at ASC
		            LIMIT 1
		        )
		        ORDER BY r.wpm DESC, r.accuracy DESC, r.completed_at ASC
		        LIMIT ?
		        """;
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection(url, username, dbPassword);
		PreparedStatement pst = con.prepareStatement(query);
		pst.setInt(1, limit);
		ResultSet rs = pst.executeQuery();
		
		List<LeaderboardEntry> leaderboard = new ArrayList<>();
		int rank = 1;
		 
        while (rs.next()) {
            LeaderboardEntry entry = new LeaderboardEntry();
            entry.setRank(rank++);
            entry.setUserId(rs.getInt("user_id"));
            entry.setUsername(rs.getString("username"));
            entry.setWpm(rs.getDouble("wpm"));
            entry.setAccuracy(rs.getDouble("accuracy"));
            entry.setDurationSeconds(rs.getInt("duration_seconds"));
            entry.setCompletedAt(rs.getTimestamp("completed_at"));

            leaderboard.add(entry);
        }
        return leaderboard;
	}
	public static UserProfile myProfileDAO(int userId) throws ClassNotFoundException, SQLException {
        String query = """
                SELECT u.user_id, u.username, u.email, u.phone_number, u.created_at,
                       COUNT(r.result_id)                      AS total_tests,
                       ROUND(COALESCE(MAX(r.wpm), 0), 2)       AS best_wpm,
                       ROUND(COALESCE(AVG(r.wpm), 0), 2)       AS avg_wpm,
                       ROUND(COALESCE(AVG(r.accuracy), 0), 2)  AS avg_accuracy
                FROM users u
                LEFT JOIN typing_results r ON r.user_id = u.user_id
                WHERE u.user_id = ?
                GROUP BY u.user_id, u.username, u.email, u.phone_number, u.created_at
                """;
 
        Class.forName("com.mysql.cj.jdbc.Driver");
 
        try (Connection con = DriverManager.getConnection(url, username, dbPassword);
             PreparedStatement pst = con.prepareStatement(query)) {
 
            pst.setInt(1, userId);
 
            try (ResultSet rs = pst.executeQuery()) {
                if (!rs.next()) {
                    return null;
                }
 
                UserProfile profile = new UserProfile();
                profile.setUserId(rs.getInt("user_id"));
                profile.setUsername(rs.getString("username"));
                profile.setEmail(rs.getString("email"));
                profile.setPhoneNumber(rs.getString("phone_number"));
                profile.setCreatedAt(rs.getTimestamp("created_at"));
                profile.setTotalTests(rs.getInt("total_tests"));
                profile.setBestWpm(rs.getDouble("best_wpm"));
                profile.setAvgWpm(rs.getDouble("avg_wpm"));
                profile.setAvgAccuracy(rs.getDouble("avg_accuracy"));
 
                return profile;
            }
        }
    }
	public static List<TypingResult> myResultsDAO(int userId, int limit)
            throws ClassNotFoundException, SQLException {
 
        String query = """
                SELECT result_id, wpm, accuracy, duration_seconds, completed_at
                FROM typing_results
                WHERE user_id = ?
                ORDER BY completed_at DESC, result_id DESC
                LIMIT ?
                """;
 
        Class.forName("com.mysql.cj.jdbc.Driver");
 
        List<TypingResult> results = new ArrayList<>();
 
        try (Connection con = DriverManager.getConnection(url, username, dbPassword);
             PreparedStatement pst = con.prepareStatement(query)) {
 
            pst.setInt(1, userId);
            pst.setInt(2, limit);
 
            try (ResultSet rs = pst.executeQuery()) {
                while (rs.next()) {
                    TypingResult r = new TypingResult();
                    r.setResultId(rs.getInt("result_id"));
                    r.setWpm(rs.getDouble("wpm"));
                    r.setAccuracy(rs.getDouble("accuracy"));
                    r.setDurationSeconds(rs.getInt("duration_seconds"));
                    r.setCompletedAt(rs.getTimestamp("completed_at"));
 
                    results.add(r);
                }
            }
        }
 
        return results;
    }
}

