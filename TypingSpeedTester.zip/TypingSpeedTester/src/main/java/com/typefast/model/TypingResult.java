package com.typefast.model;
 
import java.sql.Timestamp;
 
/**
 * One row of the typing_results table (a single test attempt).
 */
public class TypingResult {
 
    private int resultId;
    private double wpm;
    private double accuracy;
    private int durationSeconds;
    private Timestamp completedAt;
 
    public TypingResult() {
    }
 
    public int getResultId() {
        return resultId;
    }
 
    public void setResultId(int resultId) {
        this.resultId = resultId;
    }
 
    public double getWpm() {
        return wpm;
    }
 
    public void setWpm(double wpm) {
        this.wpm = wpm;
    }
 
    public double getAccuracy() {
        return accuracy;
    }
 
    public void setAccuracy(double accuracy) {
        this.accuracy = accuracy;
    }
 
    public int getDurationSeconds() {
        return durationSeconds;
    }
 
    public void setDurationSeconds(int durationSeconds) {
        this.durationSeconds = durationSeconds;
    }
 
    public Timestamp getCompletedAt() {
        return completedAt;
    }
 
    public void setCompletedAt(Timestamp completedAt) {
        this.completedAt = completedAt;
    }
 
    @Override
    public String toString() {
        return "TypingResult [resultId=" + resultId + ", wpm=" + wpm + ", accuracy=" + accuracy
                + ", durationSeconds=" + durationSeconds + "]";
    }
}
 