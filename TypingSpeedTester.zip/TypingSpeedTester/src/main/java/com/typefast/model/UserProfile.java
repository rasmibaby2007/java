package com.typefast.model;
 
import java.sql.Timestamp;
 
/**
 * One user's profile details plus their typing statistics.
 */
public class UserProfile {
 
    private int userId;
    private String username;
    private String email;
    private String phoneNumber;
    private Timestamp createdAt;
 
    private int totalTests;
    private double bestWpm;
    private double avgWpm;
    private double avgAccuracy;
 
    public UserProfile() {
    }
 
    public int getUserId() {
        return userId;
    }
 
    public void setUserId(int userId) {
        this.userId = userId;
    }
 
    public String getUsername() {
        return username;
    }
 
    public void setUsername(String username) {
        this.username = username;
    }
 
    public String getEmail() {
        return email;
    }
 
    public void setEmail(String email) {
        this.email = email;
    }
 
    public String getPhoneNumber() {
        return phoneNumber;
    }
 
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
 
    public Timestamp getCreatedAt() {
        return createdAt;
    }
 
    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }
 
    public int getTotalTests() {
        return totalTests;
    }
 
    public void setTotalTests(int totalTests) {
        this.totalTests = totalTests;
    }
 
    public double getBestWpm() {
        return bestWpm;
    }
 
    public void setBestWpm(double bestWpm) {
        this.bestWpm = bestWpm;
    }
 
    public double getAvgWpm() {
        return avgWpm;
    }
 
    public void setAvgWpm(double avgWpm) {
        this.avgWpm = avgWpm;
    }
 
    public double getAvgAccuracy() {
        return avgAccuracy;
    }
 
    public void setAvgAccuracy(double avgAccuracy) {
        this.avgAccuracy = avgAccuracy;
    }
 
    @Override
    public String toString() {
        return "UserProfile [userId=" + userId + ", username=" + username + ", email=" + email
                + ", totalTests=" + totalTests + ", bestWpm=" + bestWpm
                + ", avgWpm=" + avgWpm + ", avgAccuracy=" + avgAccuracy + "]";
    }
}
 