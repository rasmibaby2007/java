package com.typefast.model;

import java.sql.Timestamp;

/**
 * One row of the leaderboard: a user's best typing result.
 */
public class LeaderboardEntry {

    private int rank;
    private int userId;
    private String username;
    private double wpm;
    private double accuracy;
    private int durationSeconds;
    private Timestamp completedAt;

    public LeaderboardEntry() {
    }

    public LeaderboardEntry(int rank, int userId, String username, double wpm,
                            double accuracy, int durationSeconds, Timestamp completedAt) {
        this.rank = rank;
        this.userId = userId;
        this.username = username;
        this.wpm = wpm;
        this.accuracy = accuracy;
        this.durationSeconds = durationSeconds;
        this.completedAt = completedAt;
    }

    public int getRank() {
        return rank;
    }

    public void setRank(int rank) {
        this.rank = rank;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public double getWpm() {
        return wpm;
    }

    public void setWpm(double wpm) {
        this.wpm = wpm;
    }

    public double getAccuracy() {
        return accuracy;
    }

    public void setAccuracy(double accuracy) {
        this.accuracy = accuracy;
    }

    public int getDurationSeconds() {
        return durationSeconds;
    }

    public void setDurationSeconds(int durationSeconds) {
        this.durationSeconds = durationSeconds;
    }

    public Timestamp getCompletedAt() {
        return completedAt;
    }

    public void setCompletedAt(Timestamp completedAt) {
        this.completedAt = completedAt;
    }

    @Override
    public String toString() {
        return "LeaderboardEntry [rank=" + rank + ", username=" + username
                + ", wpm=" + wpm + ", accuracy=" + accuracy
                + ", durationSeconds=" + durationSeconds + "]";
    }
}
