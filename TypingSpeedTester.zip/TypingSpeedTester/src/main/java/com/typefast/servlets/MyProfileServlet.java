package com.typefast.servlets;
 
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.typefast.dao.DAOs;
import com.typefast.model.TypingResult;
import com.typefast.model.UserProfile;
 
@WebServlet("/MyProfileServlet")
public class MyProfileServlet extends HttpServlet {
 
    private static final long serialVersionUID = 1L;
 
    // Where users go when they are not logged in.
    private static final String SIGN_IN_PAGE = "http://127.0.0.1:5500/signin.html";
 
    // How many recent tests to show on the profile.
    private static final int RECENT_LIMIT = 10;
 
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
 
        // 1. Who is asking? The id comes from the session, never from the URL.
        HttpSession session = req.getSession(false);
        Object uid = (session == null) ? null : session.getAttribute("user_id");
 
        if (!(uid instanceof Number)) {
            res.sendRedirect(SIGN_IN_PAGE);
            return;
        }
 
        int userId = ((Number) uid).intValue();
 
        // 2. Load the profile and the recent results.
        try {
            UserProfile profile = DAOs.myProfileDAO(userId);
 
            if (profile == null) {
                // The account no longer exists: end the session and ask them to sign in again.
                session.invalidate();
                res.sendRedirect(SIGN_IN_PAGE);
                return;
            }
 
            List<TypingResult> results = DAOs.myResultsDAO(userId, RECENT_LIMIT);
 
            req.setAttribute("profile", profile);
            req.setAttribute("results", results);
 
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            req.setAttribute("results", new ArrayList<TypingResult>());
            req.setAttribute("error", "Could not load your profile right now. Please try again.");
        }
 
        // 3. Show the page (same folder your leaderboard.jsp is forwarded from).
        req.getRequestDispatcher("/pages/myprofile.jsp").forward(req, res);
    }
}
 