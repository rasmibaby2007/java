package com.typefast.servlets;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.typefast.dao.DAOs;

// If your TypingResultsDB class is in another package, add its import here.
// import com.typefast.dao.TypingResultsDB;

@WebServlet("/TypingServlet")
public class TypingServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    // Answer key lives on the server. Ids must match typing-test.js.
    private static final Map<Integer, String> SENTENCES = new HashMap<>();

    static {
        SENTENCES.put(1, "Typing is a useful skill that improves with regular practice. Focus on accuracy first, then gradually increase your speed.");
        SENTENCES.put(2, "Technology helps people solve problems, share ideas, and learn new skills. Practice every day to build confidence.");
        SENTENCES.put(3, "Success does not happen overnight. Small improvements made consistently can lead to great results.");
        SENTENCES.put(4, "Programming teaches us to think logically and solve problems step by step. Every expert was once a beginner.");
        SENTENCES.put(5, "Good habits make difficult tasks easier. Stay patient, learn from mistakes, and keep working towards your goals.");
    }

    // Someone opened /TypingServlet directly in the browser: send them to the test page.
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.sendRedirect("http://127.0.0.1:5500/signin.html");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        // Must be set BEFORE the first getParameter call.
        req.setCharacterEncoding("UTF-8");

        // 1. Logged-in user (comes from the session, never from the form)
        HttpSession session = req.getSession(false);
        Integer userId = (session == null) ? null : (Integer) session.getAttribute("user_id");

        if (userId == null) {
            resp.sendRedirect("http://127.0.0.1:5500/signin.html");
            return;
        }

        // 2. Read the three form values
        String idParam = req.getParameter("sentenceId");
        String typedText = req.getParameter("typedText");
        String msParam = req.getParameter("elapsedMs");

        int sentenceId;
        long elapsedMs;

        try {
            sentenceId = Integer.parseInt(idParam);
            elapsedMs = Long.parseLong(msParam);
        } catch (NumberFormatException e) {
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid request");
            return;
        }

        String expected = SENTENCES.get(sentenceId);

        if (expected == null || typedText == null || elapsedMs <= 0) {
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid request");
            return;
        }

        // 3. Compare words
        String[] expectedWords = expected.trim().split("\\s+");
        String trimmedTyped = typedText.trim();
        String[] typedWords = trimmedTyped.isEmpty() ? new String[0] : trimmedTyped.split("\\s+");

        int correctWords = 0;
        for (int i = 0; i < typedWords.length && i < expectedWords.length; i++) {
            if (typedWords[i].equals(expectedWords[i])) {
                correctWords++;
            }
        }

        // 4. Accuracy: matching characters at the same position / longer of the two texts
        int matchingChars = 0;
        int minLen = Math.min(trimmedTyped.length(), expected.length());
        for (int i = 0; i < minLen; i++) {
            if (trimmedTyped.charAt(i) == expected.charAt(i)) {
                matchingChars++;
            }
        }
        int maxLen = Math.max(trimmedTyped.length(), expected.length());
        double accuracy = (maxLen == 0) ? 0 : round2(matchingChars * 100.0 / maxLen);

        // 5. WPM: correct words per minute
        double minutes = elapsedMs / 60000.0;
        double wpm = round2(correctWords / minutes);

        int durationSeconds = (int) Math.max(1, Math.round(elapsedMs / 1000.0));

        // 6. Save to the database (a DB failure should not hide the result from the user)
        boolean saved = true;
        try {
            DAOs.addTypingResults(userId, wpm, accuracy, durationSeconds);
        } catch (Exception e) {
            saved = false;
            e.printStackTrace();
        }

        // 7. Hand the values to result.jsp and forward to it
        req.setAttribute("seconds", String.format("%.2f", elapsedMs / 1000.0));
        req.setAttribute("wpm", wpm);
        req.setAttribute("correctWords", correctWords);
        req.setAttribute("accuracy", accuracy);
        req.setAttribute("saved", saved);

        req.getRequestDispatcher("/pages/result.jsp").forward(req, resp);
    }

    private double round2(double value) {
        return Math.round(value * 100.0) / 100.0;
    }
}
