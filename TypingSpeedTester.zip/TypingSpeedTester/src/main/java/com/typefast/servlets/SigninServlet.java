package com.typefast.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.typefast.dao.DAOs;

@WebServlet("/UserLoginServlet")
public class SigninServlet extends HttpServlet{
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
		PrintWriter writer = res.getWriter();
		//writer.print("From Signin Page");
		String email = req.getParameter("email");
		String password = req.getParameter("password");
		//writer.print(contact+"\n");
		//writer.print(password);
		int user_id = 0;
		try {
			user_id = DAOs.signin(email, password);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(user_id != 0) {
			HttpSession session = req.getSession();
			session.setAttribute("user_id", user_id);
			session.setAttribute("email", email);
			//writer.print(user_id);
			res.sendRedirect("http://127.0.0.1:5500/dashboard.html");
		}
		else {
			res.sendRedirect("http://127.0.0.1:5500/signin-error.html");
		}
	}
}
