package com.typefast.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.typefast.dao.*;

@WebServlet("/SignupServlet")
public class SignupServlet extends HttpServlet{
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
		String user_name = req.getParameter("username");
		String email = req.getParameter("email");
		String phone = req.getParameter("phone_number");
		String password = req.getParameter("password");
		String confirm_password = req.getParameter("confirmPassword");
		PrintWriter writer = res.getWriter();
		boolean aboutNext = false;
		if(!password.equals(confirm_password)) {
			res.sendRedirect("http://127.0.0.1:5500/password-mismatch.html");
		}
		try {
			aboutNext = DAOs.userSignupCheck(user_name, phone, email);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(aboutNext);
		try {
			if(aboutNext) {
				res.sendRedirect("http://127.0.0.1:5500/signup-error.html");
			}
			else {
				DAOs.userSignup(user_name, phone, email, confirm_password);
				res.sendRedirect("http://127.0.0.1:5500/signup-success.html");
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
