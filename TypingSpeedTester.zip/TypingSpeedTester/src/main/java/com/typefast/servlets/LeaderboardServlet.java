package com.typefast.servlets;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.typefast.dao.DAOs;

@WebServlet("/LeaderboardServlet")
public class LeaderboardServlet extends HttpServlet{
	public void doGet(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException{
		List leaderboard = null;
		try {
			leaderboard = DAOs.leaderboardDAO(0);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		req.setAttribute("leaderboard", leaderboard);
		req.getRequestDispatcher("/pages/leaderboard.jsp").forward(req, res);
	}

}
