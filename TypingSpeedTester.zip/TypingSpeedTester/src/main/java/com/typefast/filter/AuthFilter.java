/*package com.typefast.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

//import jdk.internal.misc.FileSystemOption;

@WebFilter(urlPatterns = {
    "/dashboard.html",
    "/typing-test.jsp",
    "/my-profile.jsp"
})
public class AuthFilter implements Filter {

    @Override
    public void doFilter(
            ServletRequest request,
            ServletResponse response,
            FilterChain chain)
            throws IOException, ServletException {
    	    System.out.println("Filter is working ");

        HttpServletRequest req =
                (HttpServletRequest) request;

        HttpServletResponse res =
                (HttpServletResponse) response;

        HttpSession session = req.getSession(false);

        if (session == null ||
                session.getAttribute("userId") == null) {

            res.sendRedirect(
                    req.getContextPath() + "http://127.0.0.1:5500/signin.html");
            return;
        }

        chain.doFilter(request, response);
    }
}*/


