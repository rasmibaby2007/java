// Optional URL parameters show which detail is duplicated.
// Examples: signup-error.html?field=username, ?field=email, or ?field=phone
// IMPORTANT: Your Servlet must check the database for duplicates.
// This JavaScript only displays the message; it does not prevent duplicate accounts.

const params = new URLSearchParams(window.location.search);
const field = (params.get("field") || "").toLowerCase();

const messages = {
  username: {
    title: "Username is already in use.",
    detail: "That username has already been registered. Please choose another username."
  },
  email: {
    title: "Email is already registered.",
    detail: "An account already uses this email address. Try signing in or use another email."
  },
  phone: {
    title: "Phone number is already in use.",
    detail: "That phone number has already been registered. Please enter a different number."
  }
};

if (messages[field]) {
  document.getElementById("error-title").textContent = messages[field].title;
  document.getElementById("detail-message").textContent = messages[field].detail;
  document.getElementById("error-message").textContent =
    "We couldn't create your account because this detail is already linked to an existing account.";
}
