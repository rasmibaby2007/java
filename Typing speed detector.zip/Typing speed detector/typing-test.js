const sentences = [
    {
        id: 1,
        text: "Typing is a useful skill that improves with regular practice. Focus on accuracy first, then gradually increase your speed."
    },
    {
        id: 2,
        text: "Technology helps people solve problems, share ideas, and learn new skills. Practice every day to build confidence."
    },
    {
        id: 3,
        text: "Success does not happen overnight. Small improvements made consistently can lead to great results."
    },
    {
        id: 4,
        text: "Programming teaches us to think logically and solve problems step by step. Every expert was once a beginner."
    },
    {
        id: 5,
        text: "Good habits make difficult tasks easier. Stay patient, learn from mistakes, and keep working towards your goals."
    }
];

const sentenceText = document.getElementById("sentenceText");
const sentenceNumber = document.getElementById("sentenceNumber");
const typingInput = document.getElementById("typingInput");

const typingForm = document.getElementById("typingForm");
const sentenceIdInput = document.getElementById("sentenceIdInput");
const elapsedMsInput = document.getElementById("elapsedMsInput");

const startBtn = document.getElementById("startBtn");
const stopBtn = document.getElementById("stopBtn");
const newSentenceBtn = document.getElementById("newSentenceBtn");

const statusBadge = document.getElementById("statusBadge");
const message = document.getElementById("message");

let currentSentence = null;
let startTime = null;
let testRunning = false;
let lastSentenceId = null;

function selectRandomSentence() {
    let available = sentences.filter(
        sentence => sentence.id !== lastSentenceId
    );

    if (available.length === 0) {
        available = sentences;
    }

    const index = Math.floor(Math.random() * available.length);

    currentSentence = available[index];
    lastSentenceId = currentSentence.id;

    sentenceText.textContent = currentSentence.text;
    sentenceNumber.textContent = `Sentence ${currentSentence.id}`;

    resetTest();
}

function resetTest() {
    startTime = null;
    testRunning = false;

    typingInput.value = "";
    typingInput.readOnly = false;
    typingInput.disabled = true;

    startBtn.disabled = false;
    stopBtn.disabled = true;
    newSentenceBtn.disabled = false;

    statusBadge.textContent = "READY";

    setMessage("Select a sentence and press Start Test when you are ready.");
}

function setMessage(text, type = "") {
    message.textContent = text;
    message.className = "message";

    if (type) {
        message.classList.add(type);
    }
}

function startTest() {
    if (testRunning || !currentSentence) {
        return;
    }

    typingInput.value = "";
    typingInput.disabled = false;

    startTime = null;
    testRunning = true;

    startBtn.disabled = true;
    stopBtn.disabled = false;
    newSentenceBtn.disabled = true;

    statusBadge.textContent = "IN PROGRESS";

    setMessage("Type the displayed sentence, then click Stop Test.");

    typingInput.focus();
}

function stopTest() {
    if (!testRunning || startTime === null) {
        setMessage("Start typing before stopping the test.", "error");
        return;
    }

    const elapsedMs = Date.now() - startTime;

    // Fill the hidden fields. The typed text is sent by the textarea itself
    // (name="typedText"), so nothing else needs to be copied.
    sentenceIdInput.value = currentSentence.id;
    elapsedMsInput.value = elapsedMs;

    testRunning = false;

    // readOnly (not disabled), because disabled fields are NOT submitted.
    typingInput.readOnly = true;
    stopBtn.disabled = true;

    statusBadge.textContent = "PROCESSING";
    setMessage("Calculating your result...");

    // Normal form POST: the servlet reads sentenceId, typedText and elapsedMs
    // with req.getParameter(...) and then forwards to result.jsp.
    typingForm.submit();
}

// The timer starts on the first actual keystroke, not on the Start click.
typingInput.addEventListener("input", () => {
    if (!testRunning) {
        return;
    }

    if (startTime === null && typingInput.value.length > 0) {
        startTime = Date.now();
        setMessage("Timer started. Keep typing!");
    }
});

startBtn.addEventListener("click", startTest);
stopBtn.addEventListener("click", stopTest);
newSentenceBtn.addEventListener("click", selectRandomSentence);

// If the user comes back with the browser's Back button, start fresh.
window.addEventListener("pageshow", (event) => {
    if (event.persisted) {
        selectRandomSentence();
    }
});

// Load a random sentence when the page opens.
selectRandomSentence();
