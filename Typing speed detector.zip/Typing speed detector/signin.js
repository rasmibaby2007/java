const form=document.getElementById("signinForm");
const email=document.getElementById("email"), password=document.getElementById("password");
const emailError=document.getElementById("emailError"), passwordError=document.getElementById("passwordError");
const message=document.getElementById("formMessage");
document.getElementById("togglePassword").addEventListener("click",function(){const show=password.type==="password";password.type=show?"text":"password";this.textContent=show?"Hide":"Show";this.setAttribute("aria-label",show?"Hide password":"Show password")});
form.addEventListener("submit",function(e){emailError.textContent="";passwordError.textContent="";message.textContent="";let ok=true;const value=email.value.trim();if(!value){emailError.textContent="Please enter your email address.";ok=false}else if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)){emailError.textContent="Enter a valid email address.";ok=false}if(!password.value){passwordError.textContent="Please enter your password.";ok=false}if(!ok){e.preventDefault();message.textContent="Please check the highlighted fields."}});
// LoginServlet is a placeholder endpoint. Connect it to your Java Servlet when running on Tomcat.
